# Stubb — Design System Hand-off

Static, look-only mockup for Stubb, a ticket-hosting app. **No backend, auth, payments, or data
persistence is implemented.** Every page is real markup and real CSS — nothing here is a generated
image — but all data is hard-coded sample content, and interactive elements (toggles, modals, the
stepper, the dropdown menu) are wired with a small JS shim purely so the *states* are visible. Treat
this as the visual and structural spec to build real functionality against.

## Concept

The whole system is built around the literal object the app is named for: a torn ticket stub.
Perforated dashed seams and punched circular notches mark every boundary between two states —
browsing → buying, info → price, unpaid → paid. The signature element is the QR ticket itself
(`ticket-page.html`), styled as an actual stub with a torn perforation between the event details and
the QR stamp.

- **Dark mode is the default** (`<html>` has no class). Light mode is `<html class="theme-light">`,
  toggled via `[data-theme-toggle]` elements (see `js/app.js`).
- **Accent color**: stub-orange (`--accent`, `#ff5a1f`). Used for primary actions, links, and the
  perforation/eyebrow motif. Used sparingly — it's the one bold color in an otherwise neutral ink/paper
  palette.
- **Type**: Space Grotesk (display/headings), Inter (body), JetBrains Mono (codes, prices, timestamps,
  anything that should read as "stamped").

## File map

```
index.html                       Public homepage — event discovery grid
login.html                       Auth entry + first-time account-type picker (user vs organisation)
account.html                     Organisation account settings (banner, name, description, Stripe)
settings.html                    Dark mode toggle, version, buy-me-a-coffee
events-user.html                 Grid of events a signed-in user has bought tickets for
events-organisation.html         Owner's grid of hosted events, with "+ New event" and per-card Manage
events-organisation-public.html  PUBLIC shareable org storefront (the .../events/WeTheFree link) — no owner controls
event-editor.html                Create/edit event form (cover image, details, date/time, tickets, gallery)
event-preview.html               Preview state shown before publishing, with Create/Continue editing/Discard
event-page.html                  Live event detail + checkout sidebar, shown here in "owner viewing their own event" state
event-page-closed.html           Reference sheet: past-event and sold-out checkout states
checkout.html                    Buyer detail capture (name/email) before Stripe handoff
ticket-page.html                 The issued QR ticket — the signature component
manage-event.html                Attendee table, check-in checkboxes, payment status, QR scan modal
email-ticket.html                Standalone confirmation email template (self-contained inline CSS — see note below)

css/tokens.css        Color, type, spacing, radius, motion variables + the perforation/notch primitives
css/components.css    Nav, buttons, badges, event cards, forms, tables, modals, toasts, empty states
css/ticket.css        The signature ticket-stub component
css/<page>.css        Page-specific layout rules
js/app.js             Presentation-only behavior shim: theme toggle, dropdown menus, modals, toggles,
                      checkboxes, stepper. Replace with real logic — none of this persists or calls an API.
```

## Things still needing real functionality (not exhaustive — see original brief)

- Auth against the Wholegrain Studios account system; account-type (user/organisation) persistence
- Stripe Connect onboarding + the account page's "connected" state is currently hard-coded to "Active"
- Event CRUD, image upload, capacity/sold-count logic, the "past event" auto-categorization
- Real checkout → Stripe Checkout/Payment Element handoff, webhook handling, signature verification
- QR code generation (ticket-page.html currently renders a static decorative SVG, not a real QR code)
- Camera-based QR scanning in the Manage Event modal (`.scan-modal` is currently a static placeholder)
- The "already checked in" toast (`#duplicate-toast` in manage-event.html) — markup exists, never triggered
- Email delivery for `email-ticket.html`, including the "Open in app" deep link
- Search, filtering, and sorting on the homepage and Manage Event table (UI present, not functional)

## Note on email-ticket.html

This file intentionally does **not** use the shared `css/` files or Google Fonts `<link>` — email
clients strip external stylesheets and often block remote font loading, so all styling is inlined
in a single `<style>` block using web-safe fallbacks. Keep it that way; don't refactor it to share
CSS with the rest of the app.

## Known intentional inconsistencies

- `event-page.html` shows the **organisation-owner** view (orange "you host this event" bar, Edit/
  Manage/Delete). The same template should conditionally hide that bar and show the buyer checkout
  flow when the viewer isn't the owner — both states are designed, just not toggled dynamically here.
- `events-organisation.html` (owner's private dashboard) and `events-organisation-public.html` (public
  storefront) are deliberately separate pages/files since they have different audiences and controls,
  even though they share the same event-grid visual language.
