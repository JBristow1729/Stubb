/* ==========================================================================
   STUBB — UI behavior shim (presentation only)
   Demonstrates interaction states for the design hand-off. No data layer,
   no auth, no payments — Codex wires the real logic.
   ========================================================================== */

(function () {
  // ---- Theme toggle (dark default) ----
  const THEME_KEY = "stubb-theme-demo";
  function applyTheme(theme) {
    document.documentElement.classList.toggle("theme-light", theme === "light");
    document.querySelectorAll("[data-theme-toggle]").forEach(t => t.classList.toggle("is-on", theme === "light"));
  }
  function initTheme() {
    const saved = window.localStorage ? localStorage.getItem(THEME_KEY) : null;
    applyTheme(saved || "dark");
  }
  document.addEventListener("click", (e) => {
    const toggle = e.target.closest("[data-theme-toggle]");
    if (!toggle) return;
    const isLight = document.documentElement.classList.contains("theme-light");
    const next = isLight ? "dark" : "light";
    applyTheme(next);
    if (window.localStorage) localStorage.setItem(THEME_KEY, next);
  });

  // ---- Generic dropdown menus (profile menu etc.) ----
  document.addEventListener("click", (e) => {
    const trigger = e.target.closest("[data-menu-trigger]");
    document.querySelectorAll(".menu").forEach(menu => {
      const owner = menu.closest("[data-menu-root]");
      if (trigger && owner && owner.contains(trigger)) {
        menu.classList.toggle("is-visible");
      } else if (!menu.contains(e.target)) {
        menu.classList.remove("is-visible");
      }
    });
  });

  // ---- Generic modal open/close ----
  document.addEventListener("click", (e) => {
    const opener = e.target.closest("[data-modal-open]");
    if (opener) {
      const id = opener.getAttribute("data-modal-open");
      const modal = document.getElementById(id);
      if (modal) modal.classList.add("is-visible");
    }
    const closer = e.target.closest("[data-modal-close]");
    if (closer) {
      closer.closest(".modal-overlay")?.classList.remove("is-visible");
    }
  });

  // ---- Generic toggle switches ----
  document.addEventListener("click", (e) => {
    const toggle = e.target.closest(".toggle:not([data-theme-toggle])");
    if (toggle) toggle.classList.toggle("is-on");
  });

  // ---- Generic checkboxes (attendee table demo) ----
  document.addEventListener("click", (e) => {
    const cb = e.target.closest(".checkbox");
    if (cb) cb.classList.toggle("is-checked");
  });

  // ---- Stepper demo (ticket quantity) ----
  document.addEventListener("click", (e) => {
    const btn = e.target.closest(".stepper__btn");
    if (!btn) return;
    const stepper = btn.closest(".stepper");
    const valEl = stepper.querySelector(".stepper__val");
    let val = parseInt(valEl.textContent, 10) || 1;
    val += btn.dataset.step === "down" ? -1 : 1;
    val = Math.max(1, val);
    valEl.textContent = val;
  });

  document.addEventListener("DOMContentLoaded", initTheme);
  initTheme();
})();
